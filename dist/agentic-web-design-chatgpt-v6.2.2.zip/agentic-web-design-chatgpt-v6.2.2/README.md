# Agentic Landing Design OS

A focused system for researching, art-directing, designing, building and reviewing one high-quality landing page. It does not own SEO, marketing operations, ecommerce or product development.

## Start

Ask one open question: what should be created, for whom and what should it achieve? Existing brand, copy, photos and references are welcome but optional. Ask only a follow-up that would materially change the result. If references are missing, research current competitors, strong category examples and relevant design galleries.

“Choose for me” delegates the preference; it does not skip research, comparison or review.

## Essential path

1. Define the objective and constraints.
2. Research the category, audience, existing identity and current references.
3. Compare content structures.
4. Define what premium means for this project, then generate one artistic master before composing the webpage.
5. Confirm that visual world once, then challenge every section for high-end value and translate the selected forms responsively.
6. Define the visual system and review it independently.
7. Choose the simplest suitable technology and build the complete structural landing.
8. Render desktop/mobile, decide image presence and role per scene, send `IH-*` briefs to the separate image loop, then validate/integrate its returned files and review the final build.

The executable order and dependencies live only in [config/pipeline.json](config/pipeline.json). The runtime entry point is [skills/agentic-web-design/SKILL.md](skills/agentic-web-design/SKILL.md).

## Design rules

- Research informs choices but never selects them automatically.
- Color, typography, composition and media are judged together while translating the master into rendered scene alternatives.
- Documentary claims require authentic media. Conceptual, representative and decorative media may be requested from the external image loop when honestly framed.
- Every landing needs a substantial scene-bearing visual unless the user explicitly requests text only.
- Effects and depth are explored in context. A 3D decision requires an identified external model/scene/tool or runtime with rights, integration proof and fallback; CSS/SVG imitation is classified as 2D and cannot masquerade as 3D.
- A screenshot or composition study is evidence, not a shippable asset.
- Delivery is valid only when final media files exist inside the implementation and the code uses them.

## Roles

The eight files in `agents/` define ownership, not eight mandatory conversations. Only the active owner contract and its linked method should be loaded. Agent 07 reviews independently; findings return to the owner.

## Technology

HTML, Astro, component frameworks, visual platforms and custom creative stacks are options, never defaults. Agent 06 compares viable choices and always includes the simplest one capable of reproducing the approved design.

## Create and validate

```bash
python tools/new_project.py my-landing
python tools/validate_gate.py G2 --project-dir projects/my-landing
python tools/validate_system.py
python tools/audit_agents.py
python tools/validate_delivery.py --project-dir projects/my-landing --implementation-root path/to/site
python -m unittest discover -s tests -v
```

## Harness externo de evaluación

El harness prueba el sistema sin añadir agentes ni fases al proyecto. Crea un run aislado, registra el orden real, limita tiempo y correcciones, exige evidencia de generación visual y prepara un snapshot para la revisión final de 07.

```text
python tools/evaluation_harness.py init --scenario institutional-event
python tools/evaluation_harness.py record --run-dir <run> --event stage_start --stage definition --agent 00
python tools/evaluation_harness.py evaluate --run-dir <run>
python tools/evaluation_harness.py packet --run-dir <run>
```

Los seis escenarios y sus límites viven en `harness/scenarios.json`. `capture` genera renders desktop/móvil con Chrome o Edge local; `execute` aplica un timeout total a un ejecutor externo.

All writes stay in the local project and implementation roots supplied by the user. Publishing or writing to an external service requires an explicit request.
